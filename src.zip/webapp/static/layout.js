// SideBar
function openNav() {
    document.getElementById("menuBar").style.width = "250px";
}

function closeNav() {
    document.getElementById("menuBar").style.width = "0";
}