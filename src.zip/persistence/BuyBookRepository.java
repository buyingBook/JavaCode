package persistence;

public class BuyBookRepository {
}
