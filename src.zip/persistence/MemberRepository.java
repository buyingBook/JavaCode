package persistence;

public class MemberRepository {
}
