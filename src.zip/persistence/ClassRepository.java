package persistence;

public class ClassRepository {
}
