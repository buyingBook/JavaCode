package persistence;

public class QnARepository {
}
