package service;

public class QnAService {
}
