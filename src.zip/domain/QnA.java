package domain;

public class QnA {
}
