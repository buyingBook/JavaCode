package domain;

public class Member {
}
