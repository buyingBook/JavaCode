package domain;

public class Class {
}
