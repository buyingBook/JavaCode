package domain;

public class BuyBook {
}
